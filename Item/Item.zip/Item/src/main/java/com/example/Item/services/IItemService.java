package com.example.Item.services;

import com.example.Item.domain.Item;

import java.util.Optional;

public interface IItemService {

    Item save(Item items);
    Optional<Item> getById (Long id);
    void deleteById(Long id);
    Optional<Item> update(Long id, Item item);
}
